/*Ejercicio 30. Escriba un programa que genere un número aleatorio A (entre 0 y 100) y le pida al
usuario que lo adivine, el usuario ingresa un número B y el programa le dirá si B es mayor o menor
que A, esto se repetirá hasta que el usuario adivine el número, en ese momento el programa le dirá
el número de intentos que tardo el usuario en adivinar el número.*/


#include <iostream>
#include <time.h>
#include <cstdlib>

using namespace std;

int main()
{
    int num1 = 0,num2=0,contador=0,limite_inferior=0,limite_superior=100;
    bool aux=false;

    srand(time(NULL));

    num1 = limite_inferior + rand() % ((limite_superior + 1) - limite_inferior);

    while(aux==false){
        cout<<"Ingrese un numero: ";cin>>num2;

        if(num1<num2){
            cout<<num2<<" Es mayor,intentalo otra vez!"<<endl;
            contador++;
        }
        else if(num1>num2){
            cout<<num2<<" Es menor,intentalo otra vez!"<<endl;
            contador++;
        }
        else if(num1==num2){
            cout<<"Acertaste!! el numero era : "<<num1<<endl;
            aux=true;
        }


    }

    cout<<"Y la canditad de intentos que tardaste en adivinar el numero fue: "<<contador<<endl;
    return 0;
}
