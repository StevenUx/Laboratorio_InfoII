/*Ejercicio 14. Escriba un programa que imprima dos columnas paralelas, una con los números del
1 al 50 y otra con los números del 50 al 1.*/

#include <iostream>
using namespace std;

int main()
{
     int columnados=50;

    for(int i=1;i<=50;i++){
        cout<<i<<"     "<<columnados<<endl;
        columnados--;
    }

    return 0;
}
