/*Ejercicio 10. Escriba un programa que pida un número N e imprima en pantalla todos los múlti-
plos de dicho número entre 1 y 100.*/

#include<iostream>
using namespace std;

int main(){
    int num,aux,result,i=1;
    cout<<"Ingrese el numero a evaluar: "; cin>>num;

    cout<<"Los multimos de "<<num<<" menores que 100 son: "<<endl;
    aux=num;

    while((aux>=1)&&(aux<=100)){
        result=num*i;
        i++;
        aux=result;
        if(result<=100){
           cout<<result<<endl;
        }
    }
    return 0;
}
