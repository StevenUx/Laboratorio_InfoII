/*Problema 6. Escriba un programa que encuentre el valor aproximado del número de euler en base
a la siguiente suma innita:*/
#include <iostream>
using namespace std;

int main()
{
    float num,fact=1,result=1,x=1;

    cout<<"Ingrese el numero de elementos: ";cin>>num;

    for(int i=1;i<num;i++){   //for que controla la cantidad de elementos de la serie
        while(x<=i){         //este ciclo saca el factorial
            fact=fact*x;
            x++;
            result=result+(1/fact);
        }


    }

   cout<<"e Es aproximadamente: "<<result<<endl;

    return 0;
}
