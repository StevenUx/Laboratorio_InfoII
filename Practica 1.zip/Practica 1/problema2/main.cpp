#include <iostream>

using namespace std;

int main()
{
    int lista[]={50000,20000,10000,5000,2000,1000,500,200,100,50,0},dinero,aux;

    cout<<"Ingrese el dinero: ";cin>>dinero;
    aux=dinero;

    for(int i=0;lista[i]!=0;i++){
        dinero=aux/lista[i];
        aux=aux%lista[i];
        cout<<lista[i]<<": "<<dinero<<endl;

    }
    if(aux>0)cout<<"Resto: "<<aux<<endl;
    else cout<<"Resto: "<<aux<<endl;
    return 0;
}
