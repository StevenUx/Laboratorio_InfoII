/*Ejercicio 16. Escriba un programa que pida constantemente números hasta que se ingrese el nú-
mero cero e imprima en pantalla el promedio de los números ingresados (excluyendo el cero).*/

#include <iostream>
using namespace std;

int main()
{
    short int num,suma=0,contador=0,promedio;

    cout << "Ingrese un numero: ";cin>>num;

    while(num!=0){
        suma+=num;
        contador++;
        cout << "Ingrese un numero: ";cin>>num;
    }

    promedio=suma/contador;
    cout << "El promedio es: "<<promedio<<endl;

    return 0;
}
