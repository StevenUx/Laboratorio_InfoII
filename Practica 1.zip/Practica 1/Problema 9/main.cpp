#include <iostream>
#include <math.h>

using namespace std;

int main(){
    int num,aux,div=0,result=0;

    cout<<"Ingrese un numero: "; cin>>num;
    aux=num;

    if(num==0){
       cout<<"La suma de todos los digitos elevados asi mismos del numero "<<aux<<" es: "<<"1";
    }
    else{
        while(num>0){
            div=num%10;
            result=result + (pow(div,div));
            num=num/10;

        }

        cout<<"La suma de todos los digitos elevados asi mismos del numero "<<aux<<" es: "<<result<<'\n';

    }

    return 0;
}
