/*Ejercicio 18. Escriba un programa que pida un número N e imprima si es o no un cuadrado per-
fecto.*/

#include <iostream>
using namespace std;

int main()
{

    short int num;
    bool encontrado=false;

    cout << "Ingresa un numero: ";cin>>num;

    for(int i=1;i<num;i++){

        if(i*i==num){
            encontrado=true;
            break;
        }
    }
    if(encontrado==true){
        cout<<num<<" ES un cuadrado perfecto!"<<endl;
    }
    else{
        cout<<num<<" NO es un cuadrado perfecto!"<<endl;
    }

    return 0;
}
