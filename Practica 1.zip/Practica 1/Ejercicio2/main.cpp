//Ejercicio 2. Escriba un programa que pida un número N e imprima en pantalla si es par o impar.

#include <iostream>
using namespace std;

int main()
{
    short int num;

    cout<<"Ingrese un numero: ";cin>>num;
    if(num%2==0){
        cout<<"El numero "<<num<<" es PAR!"<<endl;
    }
    else{
        cout<<"El numero "<<num<<" es IMPAR!"<<endl;
    }

    return 0;
}
