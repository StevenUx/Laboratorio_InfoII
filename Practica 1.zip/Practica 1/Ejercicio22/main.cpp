/*Ejercicio 22. Escriba un programa que pida una cantidad entera de segundos y la imprima en
formato horas:minutos:segundos.*/

#include <iostream>
using namespace std;

int main()
{
    int num,horas=0,minutos=0,segundos=0,aux;

    cout<<"Ingrese el tiempo: ";cin>>num;
    aux=num;

    while(aux>0){
        segundos=num%60;
        aux=num/60;
        minutos=aux%60;
        aux=aux/60;
        horas=aux%60;
        aux=aux/60;
    }

    cout<<num<<" segundos son: "<<endl<<horas<<" horas con "<<minutos<<" minutos"<<" y "<<segundos<<" segundos"<<endl;

    return 0;
}
