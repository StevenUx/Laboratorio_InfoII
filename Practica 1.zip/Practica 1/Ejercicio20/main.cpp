/*Ejercicio 20. Escriba un programa que pida un número N e imprima si es o no un palíndromo
(igual de derecha a izquierda que de izquierda a derecha).*/

#include <iostream>
using namespace std;

int main(){
    int num,aux,resultado=0;

    cout<<"Ingrese el numero a evaluar: "; cin>>num;
    aux=num;

    while(num>0){
        resultado=resultado+num%10;
        resultado=resultado*10;
        num=num/10;
    }

    if(resultado/10==aux){
        cout<<"El numero "<<aux<<" ES palindromo!"<<endl;
    }
    else{
        cout<<"el numero "<<aux<<" NO es palindromo!"<<endl;
    }
}
