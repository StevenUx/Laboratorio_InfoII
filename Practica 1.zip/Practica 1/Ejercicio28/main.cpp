/*Ejercicio 28. Escriba un programa que encuentre el valor aproximado de pi en base a la siguiente
suma innita:*/


#include <iostream>
using namespace std;

int main()
{
    float num,div=3;
    float pi=0;

    cout<<"Ingrese El numero de elementos a usar: ";cin>>num;

    for(int i=1;i<num;i++){
        if(i%2==1){
            pi=pi+(-1/div);
            div=div+2;
        }

        if(i%2==0){
            pi=pi+(1/div);
            div=div+2;
        }
    }
    pi=pi+1;
    pi=pi*4;

    cout<<"pi es apriximadamente: "<<pi<<endl;

    return 0;
}
