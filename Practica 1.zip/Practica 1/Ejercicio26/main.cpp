#include <iostream>
#include <stdlib.h>
using namespace std;


int main()
{
    int lado1=0,lado2=0,lado3=0;

    cout<<"Ingrese un lado del triangulo: ";cin>>lado1;
    cout<<"Ingrese un lado del triangulo: ";cin>>lado2;
    cout<<"Ingrese un lado del triangulo: ";cin>>lado3;

       if((abs(lado1 - lado3) < lado2) && (lado2 < (lado1 + lado3))) {
           if(lado1==lado2 && lado1==lado3){
                cout<<"Se forma un triangulo EQUILATERO de lados: "<<lado1<<", "<<lado2<<", "<<lado3<<endl;
           }
           if(lado1==lado2 && lado1!=lado3 || lado1==lado3 && lado1!=lado2 || lado2==lado3 && lado2!=lado1){
               cout<<"Se forma un triangulo ISOCELES de lados: "<<lado1<<", "<<lado2<<", "<<lado3<<endl;
           }

           if(lado1!=lado2 && lado1!=lado3 && lado2!=lado3){
               cout<<"Se forma un triangulo ESCALENO de lados: "<<lado1<<", "<<lado2<<", "<<lado3<<endl;
           }
       }
       else{
        cout<<"Las longitudes: "<<lado1<<", "<<lado2<<", "<<lado3<<" no forman un triangulo"<<endl;
       }
   return 0;
}
