#include <iostream>

using namespace std;

int main()
{
    int num1,num2;
    cout<<"Este programa imprime el residuo de la division de los numeros ingresado. "<<endl<<endl;

    cout <<"Ingrese primer numero: ";cin>>num1;

    cout<<"Ingrese segundo numero: ";cin>>num2;

    cout<<"El residuo de la division "<<num1<<"/"<<num2<<" es: "<<num1%num2<<endl;
    return 0;
}
