/*Ejercicio 6. Escriba un programa que pida dos números A y B e imprima en pantalla la potencia A^B
sin hacer uso de librerías matemáticas.*/
#include <iostream>
using namespace std;

int main(){

    int num1,num2,resultado,aux,i=1;

    cout<<"Ingrese el numero un numero: "; cin>>num1;
    cout<<"Ingrese el numero de la potencia que desea: "; cin>>num2;
    aux=num1;

    if(num2==0)cout<<num1<<"^"<<num2<<"= 1"<<"->Por que todo numero elevado a 0 es igual 1"<<endl;

    else{
        while(i<num2){
        aux=aux*num1;
        i++;
    }
        resultado=aux;
        cout<<"El resultado de "<<num1<<"^"<<num2<<" es: "<<resultado<<endl;
    }

    return 0;
}
