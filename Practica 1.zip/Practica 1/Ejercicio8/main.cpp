//Ejercicio 8. Escriba un programa que pida un número N e imprima en pantalla su factorial.

#include <iostream>

using namespace std;

int main()
{
    int num1,i=1,result=1;

    cout <<"Ingrese un numero: ";cin>>num1;

    while(i<=num1){
        result=result*i;
        i++;

    }
    cout<<"El factorial de "<<num1<<"!"<<" es : "<<result<<endl;

    return 0;
}
