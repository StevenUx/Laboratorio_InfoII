/*Ejercicio 12. Escriba un programa que pida un número N e imprima todas las potencias desde N^1
hasta N^5*/

#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int num,cont=1,aux;
    cout <<"Ingrese el numero a evaluar: ";cin>>num;
    aux=num;
    for(int i=1;i<=5;i++){
        if(i==1){
            cout<<num<<"^"<<i<<"= "<<num<<endl;
        }
        else{
            while(cont<i){
                aux=aux*num;
                cout<<num<<"^"<<i<<"= "<<aux<<endl;
                cont++;
            }
        }
    }
    return 0;
}
